# AquaWatch Jamaica — Group 13

Phase 1 **test product** for the Smart Caribbean Utilities pitch: load zone flow/pressure readings, compare a simple rule to Isolation Forest, and show explainable investigation alerts.

> Synthetic demonstration data only. Not endorsed by NWC, Miya Jamaica, or any named organisation. An alert means **investigate this pattern**, not **a leak is confirmed**.

## Quick start

```bash
cd AquaWatch
pip install -r requirements.txt
python scripts/AquaWatch_Evaluate.py
streamlit run app.py
```

## Project structure

```text
AquaWatch/
  app.py                      # Streamlit UI (Jason / Romaro)
  requirements.txt
  README.md
  TEAM_WORK_SPLIT.md          # Detailed task ownership
  data/
    AquaWatch_Synthetic_Sensor_Data.csv
    AquaWatch_Data_Notes.md
  src/
    data_loader.py            # Nicholas
    baseline.py               # Nicholas
    model.py                  # Nickel
    alerts.py                 # Nickel (+ Jason consumes)
    metrics.py                # Nicholas
  tests/
    test_pipeline.py          # Automated smoke tests
    MAHATMA_TEST_CHECKLIST.md # Manual demo checks (Mahatma)
  scripts/
    AquaWatch_Evaluate.py     # CLI metrics reproduction
  docs/
    AquaWatch_Research_and_Sources.md
    pitch/
      AquaWatch_Jamaica_Group13_Pitch.pptx
```

## Phase plan

1. **Phase 1 (now):** CSV → detect → Streamlit demo → prove metrics  
2. **Phase 2 (later only):** DB, login, hosting, field feedback — only if Phase 1 works

See [TEAM_WORK_SPLIT.md](TEAM_WORK_SPLIT.md) for the full person-by-person plan.

## Team

| Person | Role |
|---|---|
| Nathanael Coote | Team Lead |
| Nickel Small | Data & Model (primary) |
| Nicholas Smalling | Data & Model (support) |
| Jason Williams | Interface (primary) |
| Romaro Dixion | Interface (support) |
| Mahatma Williams | Tester & Presenter |
